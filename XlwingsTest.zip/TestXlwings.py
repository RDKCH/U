def main():
    import xlwings as xl
    wb = xl.Book.caller()
    a = wb.sheets(1).range("A1").value
    wb.sheets(1).range("name1").value = a * 2
    