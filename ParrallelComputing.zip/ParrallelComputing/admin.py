# -*- coding: utf-8 -*-

#%% Set working directory
import os
os.getcwd()
#os.chdir('\\kwdstr07\\GRP\\SRV\\COMMON\\GRS_Public\\For_Ashish\\Duration and zspreads')
#
os.chdir('C:\\Home\\LocDev\\ParrallelComputing')
