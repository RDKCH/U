# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 10:28:58 2017

@author: RC69175
"""

print("Hello Python Parallel Cookbook!!")
closeInput = input("Press ENTER to exit")
print("Closing calledProcess")