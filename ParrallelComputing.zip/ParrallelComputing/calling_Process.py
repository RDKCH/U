# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 10:28:58 2017

@author: RC69175
"""

##The following modules must be imported
import os
import sys
##this is the code to execute
program = "python"
print("Process calling")
arguments = ["called_Process.py"]
##we call the called_Process.py script
os.execvp(program, (program,) + tuple(arguments))
print("Good Bye!!")